from django.urls import path
from . import views


urlpatterns = [
        path('', views.home, name='home'),
	path('contact/', views.contact, name='contact'),
	path('convert/', views.convert, name='convert'),
        path('register/', views.UserRegister.as_view(), name="register"),
        path('login/', views.userLogin, name='login'),
        path('logout/', views.userLogout, name='logout'),
        path('transaction_report/', views.transactionReport, name='transaction-report'),
        path('withdraw/', views.Withdraw, name='withdraw'),
        path('deposit/', views.Deposit, name='deposit'),
        path('profile/changeUsername/', views.changeUsernameSetting,name='change-username'),
        path('profile/changePassword/', views.changePasswordSetting,name='change-password')
    ]
