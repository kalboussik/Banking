from django.apps import AppConfig


class SendmailConfig(AppConfig):
    name = 'sendmail'
